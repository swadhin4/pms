package com.pms.web.service;

import com.pms.app.view.vo.CustomerVO;


public interface CustomerService {

	public CustomerVO saveCustomer(CustomerVO customerVO) throws Exception;
}
