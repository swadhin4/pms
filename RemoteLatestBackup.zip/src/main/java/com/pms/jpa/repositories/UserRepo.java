package com.pms.jpa.repositories;
/*package com.jpa.repositories;

import com.jpa.entities.User;

public interface UserRepo {

	public User findByEmail(String email);
}
*/