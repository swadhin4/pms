package com.pms.jpa.entities;

public enum Priority {

	CRITICAL,
	HIGH,
	MEDIUM,
	LOW
}
