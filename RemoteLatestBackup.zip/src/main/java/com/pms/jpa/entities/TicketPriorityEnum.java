package com.pms.jpa.entities;

public enum TicketPriorityEnum {

	CRITICAL,

	HIGH,

	MEDIUM,

	LOW
}
