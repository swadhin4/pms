package com.pms.app.job;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



public class AutoSyncDailyJob {

	final static Logger LOGGER = LoggerFactory.getLogger(AutoSyncDailyJob.class);

	public void execute() {

	}
}