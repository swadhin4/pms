package com.pms.app.job;

public interface AutoSyncSchedulerService {
	/**
	 * Method to execute job
	 */
	public void executeAutoSyncJob();

	
}
