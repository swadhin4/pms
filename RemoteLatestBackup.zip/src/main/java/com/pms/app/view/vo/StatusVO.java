package com.pms.app.view.vo;

public class StatusVO {

}
