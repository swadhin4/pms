package com.pms.app.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class FreemarkerConfig {

   /* @Bean
    public FreeMarkerConfigurationFactoryBean getFreeMarkerConfiguration() {
        FreeMarkerConfigurationFactoryBean bean = new FreeMarkerConfigurationFactoryBean();
        bean.setTemplateLoaderPath("/WEB-INF/views/templates/");
        return bean;
    }*/
}